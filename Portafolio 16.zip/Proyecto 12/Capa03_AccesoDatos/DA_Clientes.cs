﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using CapaEntidades;
using System.Linq;

namespace Capa03_AccesoDatos
{
    public class DACliente
    {       //atributos n1
        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }

        public DACliente(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }
        //N 2  (INICIA TODO EL PROCESO CON INSERTAR) 
        public int Insertar(Clientes cliente)
        {
            int id = 0;
            //Establecer el objeto de conexión
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            //Establecer el objeto para ejecutar los comandos SQL
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO CLIENTES (NOMBRE, TELEFONO, DIRECCION)" +
                " VALUES( @NOMBRE, @TELEFONO, @DIRECCION) SELECT @@IDENTITY";
            comando.Parameters.AddWithValue("@NOMBRE", cliente.Nombre);
            comando.Parameters.AddWithValue("@TELEFONO", cliente.Telefono);
            comando.Parameters.AddWithValue("DIRECCION", cliente.Direccion);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }  //Fin de insertar


        //Comienza presentacion  21  primer paso

        //metodo listar
        public List<Clientes> ListaClientes(string condicion = "")
        {
            DataSet elDataSet = new DataSet();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;
            List<Clientes> listaClientes;

            string instruccionDB = "SELECT ID_CLIENTE, NOMBRE, TELEFONO, DIRECCION FROM CLIENTES";

            if (!string.IsNullOrEmpty(condicion))
            {
                instruccionDB = string.Format("{0} WHERE {1}", instruccionDB, condicion);
            }
            try
            {
                adapter = new SqlDataAdapter(instruccionDB, conexion);
                adapter.Fill(elDataSet, "CLIENTES");
                listaClientes = (from DataRow unaFila in elDataSet.Tables["CLIENTES"].Rows
                                 select new Clientes()
                                 {
                                     Id_Cliente = (int)unaFila[0],
                                     Nombre = unaFila[1].ToString(),
                                     Telefono = unaFila[2].ToString(),
                                     Direccion = unaFila[3].ToString()
                                 }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return listaClientes;

        }

        //PASO 15 PRESENTACIÓN 21
        public Clientes ObtenerCliente(int id)
        {
            Clientes cliente = null;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = string.Format("SELECT ID_CLIENTE, NOMBRE,TELEFONO,DIRECCION FROM " +
                "CLIENTES WHERE ID_CLIENTE = {0}", id);
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                if (dataReader.HasRows)
                {
                    cliente = new Clientes();
                    dataReader.Read();
                    cliente.Id_Cliente = dataReader.GetInt32(0);
                    cliente.Nombre = dataReader.GetString(1);
                    cliente.Telefono = dataReader.GetString(2);
                    cliente.Direccion = dataReader.GetString(3);
                    cliente.Existe = true;

                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return cliente;
        }  //fin obtener cliente 

        //presentación 22 paso 2 
        public int EliminarRegistroConSP(Clientes cliente)
        {
            int resultado = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            comando.CommandText = "Eliminar";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@idcliente", cliente.Id_Cliente);
            comando.Parameters.Add("@msj", SqlDbType.VarChar, 50).Direction = ParameterDirection.Output;
            comando.Parameters.Add("@retorno", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                resultado = Convert.ToInt32(comando.Parameters["@retorno"].Value);
                _mensaje = comando.Parameters["@msj"].Value.ToString();
                conexion.Close();
            } catch (Exception)
            {
                throw;
            }
            return resultado;
        }//EliminarRegistroConSP fin

        //paso 5 presentación 22 (eliminar sin procedimiento almacenado)

        public int EliminarCliente(Clientes cliente)
        {
            int afectado = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "DELETE FROM CLIENTES";
            sentencia = string.Format("{0} WHERE ID_CLIENTE = {1}", sentencia, cliente.Id_Cliente);
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            try
            {
                conexion.Open();
                afectado = comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception)
            {
                throw;

            }
            finally
            {
                conexion.Dispose();
                conexion.Dispose();
            }
            return afectado;
        }
        //paso 9 se incia un nuevo procedimiento (Actualizar Cliente)
        public int Modificar(Clientes cliente)
        {
            int filasAfectadas = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "UPDATE CLIENTES SET NOMBRE=@NOMBRE, TELEFONO=@TELEFONO, DIRECCION=@DIRECCION WHERE ID_CLIENTE=@ID_CLIENTE"; 
            comando .CommandText = sentencia;
            comando .Connection = conexion;
            comando.Parameters.AddWithValue("@ID_CLIENTE", cliente.Id_Cliente);
            comando.Parameters.AddWithValue("@NOMBRE", cliente.Nombre);
            comando.Parameters.AddWithValue("@TELEFONO", cliente.Telefono);
            comando.Parameters.AddWithValue("@DIRECCION", cliente.Direccion);
            try
            {
                conexion.Open();
                filasAfectadas = comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception)
            {
                throw;

            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return filasAfectadas;


        }

        public DataSet ListarClientes(string condicion, string orden)
        {
            DataSet datos = new DataSet(); //Aqui se guardar la tabla de la consulta del sql
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;
            string sentencia = "SELECT ID_CLIENTE, NOMBRE, TELEFONO, DIRECCION FROM CLIENTES";

            if (!string.IsNullOrEmpty(condicion))
            { //si la condicion no esta vacia entonces concatene esa condicion a la sentencia
                sentencia = string.Format("{0} where {1}", sentencia, condicion);
            }

            if (!string.IsNullOrEmpty(orden))
            {//si orden no esta vacia entonces concatene ese orden a la sentencia
                sentencia = string.Format("{0} order by {1}", sentencia, orden);
            }
            try
            {
                adapter = new SqlDataAdapter(sentencia, conexion);
                //se realiza la conexion y se prepara el adaptador para ejecutar la sentencia
                adapter.Fill(datos, "Clientes");//el adaptador llena el dataset y le pone nombre 
            }
            catch (Exception)
            {
                throw;
            }
            return datos; //devuelve el dataset
        }//DataSet ListarClientes





    }



}
 