﻿using System;
using System.Collections.Generic;
using System.Text;
using Capa03_AccesoDatos;
using CapaEntidades;

namespace capa02_Logica
{
    public class Bl_Productos
    {
        //atributos
        private string _cadenaConexion;
        private string _mensaje;

        //propiedades
        public string Mensaje
        {
            get => _mensaje;
        }

        // constructor
        public Bl_Productos(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }

        //metodo para llamar al metodo insertar de la capa3accesodatos
        public int LlamarMetodoInsertar(Productos producto)
        {
            int id_producto = 0;
            DaProductos accesoDatos = new DaProductos(_cadenaConexion);
            try
            {
                id_producto = accesoDatos.Insertar(producto);
            }
            catch (Exception)
            {
                throw;
            }
            return id_producto;
        }// fin de la clase insertar

        //presentación 21 segundo paso
        //metodo para llamarlistar
        public List<Productos> llamarListaProductos(string condicion = "")
        {
            List<Productos> listaProductos;
            DaProductos accesoDatos = new DaProductos(_cadenaConexion);
            try
            {
                listaProductos = accesoDatos.ListaProductos(condicion);
            }
            catch (Exception)
            {
                throw;
            }

            return listaProductos;
        }

        //paso 16 presentación 21

        public Productos obtenerProducto(int id)
        {
            Productos producto;
            DaProductos accesoDatos = new DaProductos(_cadenaConexion);
            try
            {
                producto = accesoDatos.ObtenerProducto(id);
            }
            catch (Exception)
            {
                throw;
            }
            return producto;
        }//Obtenerfin paso 16

        /* public int EliminarsinSP(Productos producto)
         {
             int resultado;
             DaProductos accesoDatos = new DaProductos(_cadenaConexion);
             try
             {
                 resultado = accesoDatos.(producto);
             }
             catch (Exception)
             {
                 throw;
             }
             return resultado;
         }//eliminarconsp fin

         public int Modificar(Productos producto)
         {
             int filasAfectadas = 0;
             DaProductos accesoDatos = new DaProductos(_cadenaConexion);
             try
             {
                 filasAfectadas = accesoDatos.Modificar(producto);
             }
             catch (Exception)
             {
                 throw;
             }
             return filasAfectadas;
         }//finmodificar
         }

       */

        public int Modificar(Productos producto)
        {
            int filasAfectadas = 0;
            DaProductos accesoDatos = new DaProductos(_cadenaConexion);

            try
            {
                filasAfectadas = accesoDatos.Modificar(producto);
            }
            catch (Exception)
            {
                throw;
            }
            return filasAfectadas;

        }

    }
}

