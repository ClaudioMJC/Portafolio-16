﻿namespace Capas_Practica
{
    partial class FrmFacturacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFacturacion));
            dataGridView1 = new System.Windows.Forms.DataGridView();
            ID_Factura = new System.Windows.Forms.DataGridViewTextBoxColumn();
            FECHA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ID_CLIENTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            SUBTOTAL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            IMPUESTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            MONTODESCUENTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            btnBuscar = new System.Windows.Forms.Button();
            btnEliminar = new System.Windows.Forms.Button();
            btnNuevo = new System.Windows.Forms.Button();
            btnGuardar = new System.Windows.Forms.Button();
            btnSalir = new System.Windows.Forms.Button();
            txtDireccion = new System.Windows.Forms.TextBox();
            txtNombre = new System.Windows.Forms.TextBox();
            txtTelefono = new System.Windows.Forms.TextBox();
            txtIdCliente = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            textBox1 = new System.Windows.Forms.TextBox();
            textBox2 = new System.Windows.Forms.TextBox();
            label8 = new System.Windows.Forms.Label();
            dataGridView2 = new System.Windows.Forms.DataGridView();
            ID_FACTURA1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ID_PRODUCTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            CANTIDAD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            button1 = new System.Windows.Forms.Button();
            button2 = new System.Windows.Forms.Button();
            button3 = new System.Windows.Forms.Button();
            button4 = new System.Windows.Forms.Button();
            button5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_Factura, FECHA, ID_CLIENTE, SUBTOTAL, IMPUESTO, MONTODESCUENTO });
            dataGridView1.Location = new System.Drawing.Point(64, 171);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new System.Drawing.Size(729, 91);
            dataGridView1.TabIndex = 0;
            // 
            // ID_Factura
            // 
            ID_Factura.DataPropertyName = "ID_FACTURA";
            ID_Factura.HeaderText = "ID_FACTURA";
            ID_Factura.MinimumWidth = 8;
            ID_Factura.Name = "ID_Factura";
            ID_Factura.Width = 150;
            // 
            // FECHA
            // 
            FECHA.DataPropertyName = "FECHA";
            FECHA.HeaderText = "FECHA";
            FECHA.MinimumWidth = 8;
            FECHA.Name = "FECHA";
            FECHA.Width = 150;
            // 
            // ID_CLIENTE
            // 
            ID_CLIENTE.DataPropertyName = "ID_CLIENTE";
            ID_CLIENTE.HeaderText = "ID_CLIENTE";
            ID_CLIENTE.MinimumWidth = 8;
            ID_CLIENTE.Name = "ID_CLIENTE";
            ID_CLIENTE.Width = 150;
            // 
            // SUBTOTAL
            // 
            SUBTOTAL.DataPropertyName = "SUBTOTAL";
            SUBTOTAL.HeaderText = "SUBTOTAL";
            SUBTOTAL.MinimumWidth = 8;
            SUBTOTAL.Name = "SUBTOTAL";
            SUBTOTAL.Width = 150;
            // 
            // IMPUESTO
            // 
            IMPUESTO.DataPropertyName = "IMPUESTO";
            IMPUESTO.HeaderText = "IMPUESTO";
            IMPUESTO.MinimumWidth = 8;
            IMPUESTO.Name = "IMPUESTO";
            IMPUESTO.Width = 150;
            // 
            // MONTODESCUENTO
            // 
            MONTODESCUENTO.DataPropertyName = "MONTODESCUENTO";
            MONTODESCUENTO.HeaderText = "MONTODESCUENTO";
            MONTODESCUENTO.MinimumWidth = 8;
            MONTODESCUENTO.Name = "MONTODESCUENTO";
            MONTODESCUENTO.Width = 150;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnBuscar.Location = new System.Drawing.Point(64, 287);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(111, 110);
            btnBuscar.TabIndex = 35;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnBuscar.UseVisualStyleBackColor = true;
            // 
            // btnEliminar
            // 
            btnEliminar.Image = (System.Drawing.Image)resources.GetObject("btnEliminar.Image");
            btnEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnEliminar.Location = new System.Drawing.Point(202, 287);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new System.Drawing.Size(111, 110);
            btnEliminar.TabIndex = 34;
            btnEliminar.Text = "Eliminar";
            btnEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnEliminar.UseVisualStyleBackColor = true;
            // 
            // btnNuevo
            // 
            btnNuevo.Image = (System.Drawing.Image)resources.GetObject("btnNuevo.Image");
            btnNuevo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnNuevo.Location = new System.Drawing.Point(479, 287);
            btnNuevo.Name = "btnNuevo";
            btnNuevo.Size = new System.Drawing.Size(111, 110);
            btnNuevo.TabIndex = 33;
            btnNuevo.Text = "&Nuevo";
            btnNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnNuevo.UseVisualStyleBackColor = true;
            // 
            // btnGuardar
            // 
            btnGuardar.Image = (System.Drawing.Image)resources.GetObject("btnGuardar.Image");
            btnGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnGuardar.Location = new System.Drawing.Point(338, 287);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new System.Drawing.Size(111, 110);
            btnGuardar.TabIndex = 32;
            btnGuardar.Text = "&Guardar";
            btnGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnGuardar.UseVisualStyleBackColor = true;
            // 
            // btnSalir
            // 
            btnSalir.Image = (System.Drawing.Image)resources.GetObject("btnSalir.Image");
            btnSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnSalir.Location = new System.Drawing.Point(638, 296);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new System.Drawing.Size(111, 110);
            btnSalir.TabIndex = 31;
            btnSalir.Text = "&Salir";
            btnSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnSalir.UseVisualStyleBackColor = true;
            // 
            // txtDireccion
            // 
            txtDireccion.Location = new System.Drawing.Point(532, 43);
            txtDireccion.Multiline = true;
            txtDireccion.Name = "txtDireccion";
            txtDireccion.Size = new System.Drawing.Size(112, 32);
            txtDireccion.TabIndex = 30;
            // 
            // txtNombre
            // 
            txtNombre.Location = new System.Drawing.Point(341, 43);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new System.Drawing.Size(112, 31);
            txtNombre.TabIndex = 29;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new System.Drawing.Point(177, 121);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new System.Drawing.Size(112, 31);
            txtTelefono.TabIndex = 28;
            // 
            // txtIdCliente
            // 
            txtIdCliente.BackColor = System.Drawing.SystemColors.Info;
            txtIdCliente.Location = new System.Drawing.Point(177, 43);
            txtIdCliente.Name = "txtIdCliente";
            txtIdCliente.ReadOnly = true;
            txtIdCliente.Size = new System.Drawing.Size(112, 31);
            txtIdCliente.TabIndex = 27;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(177, 9);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(112, 25);
            label1.TabIndex = 36;
            label1.Text = "ID_FACTURA";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(383, 9);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(66, 25);
            label2.TabIndex = 37;
            label2.Text = "FECHA";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(354, 79);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(95, 25);
            label3.TabIndex = 38;
            label3.Text = "lMPUESTO";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(172, 78);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(92, 25);
            label4.TabIndex = 39;
            label4.Text = "SUBTOTAL";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(549, 9);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(101, 25);
            label5.TabIndex = 40;
            label5.Text = "ID_CLIENTE";
            // 
            // textBox1
            // 
            textBox1.Location = new System.Drawing.Point(341, 121);
            textBox1.Name = "textBox1";
            textBox1.Size = new System.Drawing.Size(112, 31);
            textBox1.TabIndex = 42;
            // 
            // textBox2
            // 
            textBox2.Location = new System.Drawing.Point(532, 121);
            textBox2.Name = "textBox2";
            textBox2.Size = new System.Drawing.Size(112, 31);
            textBox2.TabIndex = 43;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(512, 79);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(176, 25);
            label8.TabIndex = 45;
            label8.Text = "MONTODESCUENTO";
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_FACTURA1, ID_PRODUCTO, CANTIDAD });
            dataGridView2.Location = new System.Drawing.Point(137, 427);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 62;
            dataGridView2.RowTemplate.Height = 33;
            dataGridView2.Size = new System.Drawing.Size(529, 72);
            dataGridView2.TabIndex = 46;
            // 
            // ID_FACTURA1
            // 
            ID_FACTURA1.DataPropertyName = "ID_FACTURA";
            ID_FACTURA1.HeaderText = "ID_FACTURA";
            ID_FACTURA1.MinimumWidth = 8;
            ID_FACTURA1.Name = "ID_FACTURA1";
            ID_FACTURA1.Width = 150;
            // 
            // ID_PRODUCTO
            // 
            ID_PRODUCTO.DataPropertyName = "ID_PRODUCTO";
            ID_PRODUCTO.HeaderText = "ID_PRODUCTO";
            ID_PRODUCTO.MinimumWidth = 8;
            ID_PRODUCTO.Name = "ID_PRODUCTO";
            ID_PRODUCTO.Width = 150;
            // 
            // CANTIDAD
            // 
            CANTIDAD.DataPropertyName = "CANTIDAD";
            CANTIDAD.HeaderText = "CANTIDAD";
            CANTIDAD.MinimumWidth = 8;
            CANTIDAD.Name = "CANTIDAD";
            CANTIDAD.Width = 150;
            // 
            // button1
            // 
            button1.Image = (System.Drawing.Image)resources.GetObject("button1.Image");
            button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            button1.Location = new System.Drawing.Point(64, 505);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(111, 110);
            button1.TabIndex = 51;
            button1.Text = "&Buscar";
            button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Image = (System.Drawing.Image)resources.GetObject("button2.Image");
            button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            button2.Location = new System.Drawing.Point(202, 505);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(111, 110);
            button2.TabIndex = 50;
            button2.Text = "Eliminar";
            button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Image = (System.Drawing.Image)resources.GetObject("button3.Image");
            button3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            button3.Location = new System.Drawing.Point(479, 505);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(111, 110);
            button3.TabIndex = 49;
            button3.Text = "&Nuevo";
            button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Image = (System.Drawing.Image)resources.GetObject("button4.Image");
            button4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            button4.Location = new System.Drawing.Point(338, 505);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(111, 110);
            button4.TabIndex = 48;
            button4.Text = "&Guardar";
            button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Image = (System.Drawing.Image)resources.GetObject("button5.Image");
            button5.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            button5.Location = new System.Drawing.Point(638, 505);
            button5.Name = "button5";
            button5.Size = new System.Drawing.Size(111, 110);
            button5.TabIndex = 47;
            button5.Text = "&Salir";
            button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            button5.UseVisualStyleBackColor = true;
            // 
            // FrmFacturacion
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(812, 620);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(button3);
            Controls.Add(button4);
            Controls.Add(button5);
            Controls.Add(dataGridView2);
            Controls.Add(label8);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnBuscar);
            Controls.Add(btnEliminar);
            Controls.Add(btnNuevo);
            Controls.Add(btnGuardar);
            Controls.Add(btnSalir);
            Controls.Add(txtDireccion);
            Controls.Add(txtNombre);
            Controls.Add(txtTelefono);
            Controls.Add(txtIdCliente);
            Controls.Add(dataGridView1);
            Name = "FrmFacturacion";
            Text = "FrmFacturacion";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtIdCliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Factura;
        private System.Windows.Forms.DataGridViewTextBoxColumn FECHA;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_CLIENTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn SUBTOTAL;
        private System.Windows.Forms.DataGridViewTextBoxColumn IMPUESTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn MONTODESCUENTO;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_FACTURA1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_PRODUCTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn CANTIDAD;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}