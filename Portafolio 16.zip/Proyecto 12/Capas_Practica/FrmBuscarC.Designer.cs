﻿namespace Capas_Practica
{
    partial class FrmBuscarC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBuscarC));
            label1 = new System.Windows.Forms.Label();
            txtNombre = new System.Windows.Forms.TextBox();
            grdClientes = new System.Windows.Forms.DataGridView();
            ID_CLIENTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            nomb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            telefono = new System.Windows.Forms.DataGridViewTextBoxColumn();
            btnAceptar = new System.Windows.Forms.Button();
            btnBuscar = new System.Windows.Forms.Button();
            btnCancelar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)grdClientes).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(47, 56);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(78, 25);
            label1.TabIndex = 0;
            label1.Text = "Nombre";
            // 
            // txtNombre
            // 
            txtNombre.Location = new System.Drawing.Point(131, 56);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new System.Drawing.Size(485, 31);
            txtNombre.TabIndex = 1;
            // 
            // grdClientes
            // 
            grdClientes.AllowUserToAddRows = false;
            grdClientes.AllowUserToDeleteRows = false;
            grdClientes.AllowUserToResizeColumns = false;
            grdClientes.AllowUserToResizeRows = false;
            grdClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdClientes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_CLIENTE, nomb, nombre, telefono });
            grdClientes.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            grdClientes.Location = new System.Drawing.Point(47, 147);
            grdClientes.Name = "grdClientes";
            grdClientes.RowHeadersWidth = 62;
            grdClientes.RowTemplate.Height = 33;
            grdClientes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            grdClientes.Size = new System.Drawing.Size(701, 108);
            grdClientes.TabIndex = 2;
            grdClientes.DoubleClick += grdClientes_DoubleClick;
            // 
            // ID_CLIENTE
            // 
            ID_CLIENTE.DataPropertyName = "ID_CLIENTE";
            ID_CLIENTE.HeaderText = "Id_CLIENTE";
            ID_CLIENTE.MinimumWidth = 8;
            ID_CLIENTE.Name = "ID_CLIENTE";
            ID_CLIENTE.Width = 150;
            // 
            // nomb
            // 
            nomb.DataPropertyName = "NOMBRE";
            nomb.HeaderText = "Nombre";
            nomb.MinimumWidth = 8;
            nomb.Name = "nomb";
            nomb.Width = 150;
            // 
            // nombre
            // 
            nombre.DataPropertyName = "TELEFONO";
            nombre.HeaderText = "Télefono";
            nombre.MinimumWidth = 8;
            nombre.Name = "nombre";
            nombre.Width = 150;
            // 
            // telefono
            // 
            telefono.DataPropertyName = "DIRECCION";
            telefono.HeaderText = "Dirección";
            telefono.MinimumWidth = 8;
            telefono.Name = "telefono";
            telefono.Visible = false;
            telefono.Width = 150;
            // 
            // btnAceptar
            // 
            btnAceptar.Image = (System.Drawing.Image)resources.GetObject("btnAceptar.Image");
            btnAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnAceptar.Location = new System.Drawing.Point(637, 301);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new System.Drawing.Size(111, 110);
            btnAceptar.TabIndex = 26;
            btnAceptar.Text = " &Aceptar";
            btnAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnBuscar.Location = new System.Drawing.Point(637, 12);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(111, 110);
            btnBuscar.TabIndex = 28;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Image = (System.Drawing.Image)resources.GetObject("btnCancelar.Image");
            btnCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnCancelar.Location = new System.Drawing.Point(488, 301);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new System.Drawing.Size(111, 110);
            btnCancelar.TabIndex = 29;
            btnCancelar.Text = "Cancelar";
            btnCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // FrmBuscarC
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(btnCancelar);
            Controls.Add(btnBuscar);
            Controls.Add(btnAceptar);
            Controls.Add(grdClientes);
            Controls.Add(txtNombre);
            Controls.Add(label1);
            Name = "FrmBuscarC";
            Text = "FrmBuscarC";
            Load += FrmBuscarC_Load;
            ((System.ComponentModel.ISupportInitialize)grdClientes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.DataGridView grdClientes;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_CLIENTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomb;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefono;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnCancelar;
    }
}