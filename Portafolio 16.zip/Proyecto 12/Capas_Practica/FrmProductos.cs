﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using capa02_Logica;
using CapaEntidades;

namespace Capas_Practica
{
    public partial class FrmProductos : Form
    {
        //variable global, esto si el campo txtIdcliente.text tiene algun valor, significa que el producto existe
        //no se debe insertar se debe modificar
        Productos productoRegistrado;
        public FrmProductos()
        {
            InitializeComponent();
        }
        FrmBuscarProducto formularioBuscar;
        //crea un objeto con los datos ingresados en las casillas de texto
        public Productos generaProducto()
        {
            /*Productos producto = new Productos();
            producto.Descripcion = txtDescripcion.Text;
            producto.Precio_Compra = float.TryParse(txtPrecioCompra.Text, out float precio) ? precio : 0.0f;
            producto.Precio_Venta = float.TryParse(txtPrecioVenta.Text, out float precio1) ? precio1 : 0.0f;
            producto.Gravado = textGravado.Text;
            return producto;
            */
            Productos producto;
            if (!string.IsNullOrEmpty(txtIdProducto.Text))
            {
                producto = productoRegistrado;
            }
            else
            {
                producto = new Productos();
            }
            producto.Descripcion = txtDescripcion.Text;
            producto.Precio_Compra = Convert.ToSingle(txtPrecioCompra.Text);
            producto.Precio_Venta = Convert.ToSingle(txtPrecioVenta.Text);
            producto.Gravado = textGravado.Text;
            return producto;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Productos producto = new Productos();
            Bl_Productos logicaProducto = new Bl_Productos(Configuracion.getConnectionString);
            int resultado;
            try
            {
                if (string.IsNullOrEmpty(txtDescripcion.Text) | string.IsNullOrEmpty(txtPrecioVenta.Text) | string.IsNullOrEmpty(txtPrecioCompra.Text))
                {
                    MessageBox.Show("Faltan datos", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    producto = generaProducto();
                    resultado = logicaProducto.LlamarMetodoInsertar(producto);

                    LimpiarCasillas();
                    MessageBox.Show("operacion fue exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LimpiarCasillas()
        {
            txtIdProducto.Text = string.Empty;
            txtDescripcion.Text = string.Empty;
            txtPrecioVenta.Text = string.Empty;
            txtPrecioCompra.Text = string.Empty;
            textGravado.Text = string.Empty;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void FrmClientes_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaProductos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //paso 4 presentación 21


        //paso 5 presentación 21  //SE CONFIGURA EL BOTON DE MANERA DIFERENTE EN AMBOS PASOS
        //PASA 10 PRESENTACION 21
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //FrmBuscarClientes frm = new FrmBuscarClientes();
            //frm.Show();
            formularioBuscar = new FrmBuscarProducto();
            //se especifica que se quiere usar el evento Aceptar
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();
        } //fin_btnBuscar_Click


        //Cargar los datos  presentacion 21 tercer paso
        public void CargarListaProductos(string condicion = "")
        {
            Bl_Productos logicaBuscar = new Bl_Productos(Configuracion.getConnectionString);
            List<Productos> listarProductos;
            try
            {
                listarProductos = logicaBuscar.llamarListaProductos(condicion);
                if (listarProductos.Count > 0)
                {
                    dataGridView1.DataSource = listarProductos;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //paso 11 presentación 21
        public void Aceptar(Object id, EventArgs e)
        {
            try
            {
                int idProducto = (int)id;
                if (idProducto != -1)
                {
                    //MessageBox.Show(idCliente.ToString());
                    CargarProductos(idProducto);
                }
                else
                {
                    LimpiarCasillas();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//fin aceptar

        //Paso 17 presentación 21
        private void CargarProductos(int id)
        {
            Productos Producto = new Productos();
            Bl_Productos traerCliente = new Bl_Productos(Configuracion.getConnectionString);
            try
            {
                Producto = traerCliente.obtenerProducto(id);
                if (Producto != null)
                {
                    txtIdProducto.Text = Producto.Id_Producto.ToString();
                    txtDescripcion.Text = Producto.Descripcion;
                    txtPrecioCompra.Text = Producto.Precio_Compra.ToString();
                    txtPrecioVenta.Text = Producto.Precio_Venta.ToString();
                    textGravado.Text = Producto.ToString();

                }
                else
                {
                    MessageBox.Show("El producto no se encuentra en la base de datos",
                        "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    CargarListaProductos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin cargar cliente

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCasillas();
        }

        private void btnGuardar_Click_1(object sender, EventArgs e)
        {
            Productos producto = new Productos();
            Bl_Productos logica = new Bl_Productos(Configuracion.getConnectionString);
            int resultado;
            try
            {
                if (!string.IsNullOrEmpty(txtDescripcion.Text) && !string.IsNullOrEmpty(txtPrecioCompra.Text) && !string.IsNullOrEmpty(txtPrecioVenta.Text) && !string.IsNullOrEmpty(textGravado.Text))
                {
                    producto = generaProducto();
                    if (!producto.Existe)
                    {
                        resultado = logica.LlamarMetodoInsertar(producto);
                    }
                    else
                    {
                        resultado = logica.Modificar(producto);
                    }
                    if (resultado > 0)
                    {
                        LimpiarCasillas();
                        MessageBox.Show("Operacion realizada con exito", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        CargarListaProductos();
                    }
                    else
                    {
                        MessageBox.Show("No se Realizaron cambios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Los datos son obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
