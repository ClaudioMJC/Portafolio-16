﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using capa02_Logica;
using System.Data;
namespace AppWeb___clientes_
{
    public partial class DefaultClientes : System.Web.UI.Page
    {
          
        private void CargarListaDataSet(string condicion = "", string orden = "")
        {
            //carga el datagridview con el dataset
            Bl_Clientes logica = new Bl_Clientes(clsConfiguracion.getConnectionString);
            DataSet DSClientes;

            try
            {
                DSClientes = logica.ListarClientes(condicion, orden);
                grdClientes.DataSource = DSClientes;
                grdClientes.DataMember = DSClientes.Tables[0].TableName;
                grdClientes.DataBind();
                
                //en la tabla con nombre Clientes del dataset
            }
            catch (Exception ex)
            {
                //throw
            }
        }// fin CargarListaDataSet



        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                if (!IsPostBack)
                {
                    CargarListaDataSet();
                }
            }
            catch (Exception)
            {
                //throw;
            }
           
        }
    }
}